<?php

namespace App\Helpers;

use Twilio\Rest\Client;

class TwilioHelper
{
    public static function sendSMS($to, $message)
    {
        $twilioSid = 'AC92033bc758905c69134422f76615260e';
        $twilioToken = 'bfadbf922bf957df6ab2c5adbf4db0d1';
        $twilioPhoneNumber = '+19032823029';

        $client = new Client($twilioSid, $twilioToken);

        $client->messages->create(
            $to,
            [
                'from' => $twilioPhoneNumber,
                'body' => $message,
            ]
        );
    }
}

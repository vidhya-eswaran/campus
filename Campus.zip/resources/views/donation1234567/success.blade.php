<!-- resources/views/donation/success.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Donation Successful</title>
</head>
<body>
    <h2>Thank you for your donation!</h2>
    <p>Your payment has been successfully processed.</p>
    <a href="{{ url('/') }}">Go to Home</a>
</body>
</html>

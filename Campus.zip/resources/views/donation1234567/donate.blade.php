<html lang="en-US" class="kingster-mmenu-right"><head>
    <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>
    Contact Us | Santhosha Vidhayalaya</title>
        
    
        <link rel="stylesheet" href="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/plugins/goodlayers-core/plugins/combine/style.css" type="text/css" media="all">
        <link rel="stylesheet" href="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/plugins/goodlayers-core/include/css/page-builder.css" type="text/css" media="all">
        <link rel="stylesheet" href="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/plugins/revslider/public/assets/css/settings.css" type="text/css" media="all">
        <link rel="stylesheet" href="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/css/style-core.css" type="text/css" media="all">
        <link rel="stylesheet" href="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/css/kingster-style-custom.css" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Playfair+Display:700%2C400" rel="stylesheet" property="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:ital@0;1&amp;display=swap" rel="stylesheet">
    <meta name="robots" content="max-image-preview:large">
        <style>img:is([sizes="auto" i], [sizes^="auto," i]) { contain-intrinsic-size: 3000px 1500px }</style>
        <link rel="dns-prefetch" href="//checkout.razorpay.com">
    <script type="text/javascript">
    /* <![CDATA[ */
    window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/santhoshavidhyalaya.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.7.2"}};
    /*! This file is auto-generated */
    !function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
    /* ]]> */
    </script><link type="text/css" rel="stylesheet" id="dark-mode-custom-link"><link type="text/css" rel="stylesheet" id="dark-mode-general-link"><style lang="en" type="text/css" id="dark-mode-custom-style"></style><style lang="en" type="text/css" id="dark-mode-native-style"></style><style lang="en" type="text/css" id="dark-mode-native-sheet"></style>
    <link rel="stylesheet" id="rm_material_icons-css" href="https://santhoshavidhyalaya.com/wp-content/plugins/custom-registration-form-builder-with-submission-manager/admin/css/material-icons.css?ver=6.7.2" type="text/css" media="all">
    <link rel="stylesheet" id="elementor-icons-css" href="https://santhoshavidhyalaya.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.25.0" type="text/css" media="all">
    <link rel="stylesheet" id="elementor-common-css" href="https://santhoshavidhyalaya.com/wp-content/plugins/elementor/assets/css/common.min.css?ver=3.18.3" type="text/css" media="all">
    <link rel="stylesheet" id="e-theme-ui-light-css" href="https://santhoshavidhyalaya.com/wp-content/plugins/elementor/assets/css/theme-light.min.css?ver=3.18.3" type="text/css" media="all">
    <style id="wp-emoji-styles-inline-css" type="text/css">
    
        img.wp-smiley, img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 0.07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel="stylesheet" id="wp-block-library-css" href="https://santhoshavidhyalaya.com/wp-includes/css/dist/block-library/style.min.css?ver=6.7.2" type="text/css" media="all">
    <style id="classic-theme-styles-inline-css" type="text/css">
    /*! This file is auto-generated */
    .wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
    </style>
    <style id="global-styles-inline-css" type="text/css">
    :root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
    :where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
    :where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
    :root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
    </style>
    <link rel="stylesheet" id="contact-form-7-css" href="https://santhoshavidhyalaya.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.8.6" type="text/css" media="all">
    <link rel="stylesheet" id="cf7rzp-styles-css" href="https://santhoshavidhyalaya.com/wp-content/plugins/integrate-razorpay-contact-form-7/assets/css/styles.css?ver=6.7.2" type="text/css" media="all">
    <link rel="stylesheet" id="mfcf7_zl_button_style-css" href="https://santhoshavidhyalaya.com/wp-content/plugins/multiline-files-for-contact-form-7/css/style.css?12&amp;ver=6.7.2" type="text/css" media="all">
    <link rel="stylesheet" id="cf7cf-style-css" href="https://santhoshavidhyalaya.com/wp-content/plugins/cf7-conditional-fields/style.css?ver=2.4.6" type="text/css" media="all">
    <link rel="stylesheet" id="jvcf7_client_css-css" href="https://santhoshavidhyalaya.com/wp-content/plugins/jquery-validation-for-contact-form-7/includes/assets/css/jvcf7_client.css?ver=5.4.2" type="text/css" media="all">
    <link rel="stylesheet" id="elementor-frontend-css" href="https://santhoshavidhyalaya.com/wp-content/plugins/elementor/assets/css/frontend-lite.min.css?ver=3.18.3" type="text/css" media="all">
    <link rel="stylesheet" id="eael-general-css" href="https://santhoshavidhyalaya.com/wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/css/view/general.min.css?ver=5.9.7" type="text/css" media="all">
    <!--n2css--><script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/plugins/integrate-razorpay-contact-form-7/assets/js/lib/sweetalert2.js?ver=6.7.2" id="cf7rzp-sweetalert2-js"></script><style>.swal2-popup.swal2-toast{box-sizing:border-box;grid-column:1/4!important;grid-row:1/4!important;grid-template-columns:1fr 99fr 1fr;padding:1em;overflow-y:hidden;background:#fff;box-shadow:0 0 1px rgba(0,0,0,.075),0 1px 2px rgba(0,0,0,.075),1px 2px 4px rgba(0,0,0,.075),1px 3px 8px rgba(0,0,0,.075),2px 4px 16px rgba(0,0,0,.075);pointer-events:all}.swal2-popup.swal2-toast>*{grid-column:2}.swal2-popup.swal2-toast .swal2-title{margin:.5em 1em;padding:0;font-size:1em;text-align:initial}.swal2-popup.swal2-toast .swal2-loading{justify-content:center}.swal2-popup.swal2-toast .swal2-input{height:2em;margin:.5em;font-size:1em}.swal2-popup.swal2-toast .swal2-validation-message{font-size:1em}.swal2-popup.swal2-toast .swal2-footer{margin:.5em 0 0;padding:.5em 0 0;font-size:.8em}.swal2-popup.swal2-toast .swal2-close{grid-column:3/3;grid-row:1/99;align-self:center;width:.8em;height:.8em;margin:0;font-size:2em}.swal2-popup.swal2-toast .swal2-html-container{margin:.5em 1em;padding:0;font-size:1em;text-align:initial}.swal2-popup.swal2-toast .swal2-html-container:empty{padding:0}.swal2-popup.swal2-toast .swal2-loader{grid-column:1;grid-row:1/99;align-self:center;width:2em;height:2em;margin:.25em}.swal2-popup.swal2-toast .swal2-icon{grid-column:1;grid-row:1/99;align-self:center;width:2em;min-width:2em;height:2em;margin:0 .5em 0 0}.swal2-popup.swal2-toast .swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:1.8em;font-weight:700}.swal2-popup.swal2-toast .swal2-icon.swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line]{top:.875em;width:1.375em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:.3125em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:.3125em}.swal2-popup.swal2-toast .swal2-actions{justify-content:flex-start;height:auto;margin:0;margin-top:.5em;padding:0 .5em}.swal2-popup.swal2-toast .swal2-styled{margin:.25em .5em;padding:.4em .6em;font-size:1em}.swal2-popup.swal2-toast .swal2-success{border-color:#a5dc86}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line]{position:absolute;width:1.6em;height:3em;transform:rotate(45deg);border-radius:50%}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=left]{top:-.8em;left:-.5em;transform:rotate(-45deg);transform-origin:2em 2em;border-radius:4em 0 0 4em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=right]{top:-.25em;left:.9375em;transform-origin:0 1.5em;border-radius:0 4em 4em 0}.swal2-popup.swal2-toast .swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-success .swal2-success-fix{top:0;left:.4375em;width:.4375em;height:2.6875em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line]{height:.3125em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=tip]{top:1.125em;left:.1875em;width:.75em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=long]{top:.9375em;right:.1875em;width:1.375em}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-tip{-webkit-animation:swal2-toast-animate-success-line-tip .75s;animation:swal2-toast-animate-success-line-tip .75s}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-long{-webkit-animation:swal2-toast-animate-success-line-long .75s;animation:swal2-toast-animate-success-line-long .75s}.swal2-popup.swal2-toast.swal2-show{-webkit-animation:swal2-toast-show .5s;animation:swal2-toast-show .5s}.swal2-popup.swal2-toast.swal2-hide{-webkit-animation:swal2-toast-hide .1s forwards;animation:swal2-toast-hide .1s forwards}.swal2-container{display:grid;position:fixed;z-index:1060;top:0;right:0;bottom:0;left:0;box-sizing:border-box;grid-template-areas:"top-start     top            top-end" "center-start  center         center-end" "bottom-start  bottom-center  bottom-end";grid-template-rows:minmax(-webkit-min-content,auto) minmax(-webkit-min-content,auto) minmax(-webkit-min-content,auto);grid-template-rows:minmax(min-content,auto) minmax(min-content,auto) minmax(min-content,auto);height:100%;padding:.625em;overflow-x:hidden;transition:background-color .1s;-webkit-overflow-scrolling:touch}.swal2-container.swal2-backdrop-show,.swal2-container.swal2-noanimation{background:rgba(0,0,0,.4)}.swal2-container.swal2-backdrop-hide{background:0 0!important}.swal2-container.swal2-bottom-start,.swal2-container.swal2-center-start,.swal2-container.swal2-top-start{grid-template-columns:minmax(0,1fr) auto auto}.swal2-container.swal2-bottom,.swal2-container.swal2-center,.swal2-container.swal2-top{grid-template-columns:auto minmax(0,1fr) auto}.swal2-container.swal2-bottom-end,.swal2-container.swal2-center-end,.swal2-container.swal2-top-end{grid-template-columns:auto auto minmax(0,1fr)}.swal2-container.swal2-top-start>.swal2-popup{align-self:start}.swal2-container.swal2-top>.swal2-popup{grid-column:2;align-self:start;justify-self:center}.swal2-container.swal2-top-end>.swal2-popup,.swal2-container.swal2-top-right>.swal2-popup{grid-column:3;align-self:start;justify-self:end}.swal2-container.swal2-center-left>.swal2-popup,.swal2-container.swal2-center-start>.swal2-popup{grid-row:2;align-self:center}.swal2-container.swal2-center>.swal2-popup{grid-column:2;grid-row:2;align-self:center;justify-self:center}.swal2-container.swal2-center-end>.swal2-popup,.swal2-container.swal2-center-right>.swal2-popup{grid-column:3;grid-row:2;align-self:center;justify-self:end}.swal2-container.swal2-bottom-left>.swal2-popup,.swal2-container.swal2-bottom-start>.swal2-popup{grid-column:1;grid-row:3;align-self:end}.swal2-container.swal2-bottom>.swal2-popup{grid-column:2;grid-row:3;justify-self:center;align-self:end}.swal2-container.swal2-bottom-end>.swal2-popup,.swal2-container.swal2-bottom-right>.swal2-popup{grid-column:3;grid-row:3;align-self:end;justify-self:end}.swal2-container.swal2-grow-fullscreen>.swal2-popup,.swal2-container.swal2-grow-row>.swal2-popup{grid-column:1/4;width:100%}.swal2-container.swal2-grow-column>.swal2-popup,.swal2-container.swal2-grow-fullscreen>.swal2-popup{grid-row:1/4;align-self:stretch}.swal2-container.swal2-no-transition{transition:none!important}.swal2-popup{display:none;position:relative;box-sizing:border-box;grid-template-columns:minmax(0,100%);width:32em;max-width:100%;padding:0 0 1.25em;border:none;border-radius:5px;background:#fff;color:#545454;font-family:inherit;font-size:1rem}.swal2-popup:focus{outline:0}.swal2-popup.swal2-loading{overflow-y:hidden}.swal2-title{position:relative;max-width:100%;margin:0;padding:.8em 1em 0;color:inherit;font-size:1.875em;font-weight:600;text-align:center;text-transform:none;word-wrap:break-word}.swal2-actions{display:flex;z-index:1;box-sizing:border-box;flex-wrap:wrap;align-items:center;justify-content:center;width:auto;margin:1.25em auto 0;padding:0}.swal2-actions:not(.swal2-loading) .swal2-styled[disabled]{opacity:.4}.swal2-actions:not(.swal2-loading) .swal2-styled:hover{background-image:linear-gradient(rgba(0,0,0,.1),rgba(0,0,0,.1))}.swal2-actions:not(.swal2-loading) .swal2-styled:active{background-image:linear-gradient(rgba(0,0,0,.2),rgba(0,0,0,.2))}.swal2-loader{display:none;align-items:center;justify-content:center;width:2.2em;height:2.2em;margin:0 1.875em;-webkit-animation:swal2-rotate-loading 1.5s linear 0s infinite normal;animation:swal2-rotate-loading 1.5s linear 0s infinite normal;border-width:.25em;border-style:solid;border-radius:100%;border-color:#2778c4 transparent #2778c4 transparent}.swal2-styled{margin:.3125em;padding:.625em 1.1em;transition:box-shadow .1s;box-shadow:0 0 0 3px transparent;font-weight:500}.swal2-styled:not([disabled]){cursor:pointer}.swal2-styled.swal2-confirm{border:0;border-radius:.25em;background:initial;background-color:#7066e0;color:#fff;font-size:1em}.swal2-styled.swal2-confirm:focus{box-shadow:0 0 0 3px rgba(112,102,224,.5)}.swal2-styled.swal2-deny{border:0;border-radius:.25em;background:initial;background-color:#dc3741;color:#fff;font-size:1em}.swal2-styled.swal2-deny:focus{box-shadow:0 0 0 3px rgba(220,55,65,.5)}.swal2-styled.swal2-cancel{border:0;border-radius:.25em;background:initial;background-color:#6e7881;color:#fff;font-size:1em}.swal2-styled.swal2-cancel:focus{box-shadow:0 0 0 3px rgba(110,120,129,.5)}.swal2-styled.swal2-default-outline:focus{box-shadow:0 0 0 3px rgba(100,150,200,.5)}.swal2-styled:focus{outline:0}.swal2-styled::-moz-focus-inner{border:0}.swal2-footer{justify-content:center;margin:1em 0 0;padding:1em 1em 0;border-top:1px solid #eee;color:inherit;font-size:1em}.swal2-timer-progress-bar-container{position:absolute;right:0;bottom:0;left:0;grid-column:auto!important;height:.25em;overflow:hidden;border-bottom-right-radius:5px;border-bottom-left-radius:5px}.swal2-timer-progress-bar{width:100%;height:.25em;background:rgba(0,0,0,.2)}.swal2-image{max-width:100%;margin:2em auto 1em}.swal2-close{z-index:2;align-items:center;justify-content:center;width:1.2em;height:1.2em;margin-top:0;margin-right:0;margin-bottom:-1.2em;padding:0;overflow:hidden;transition:color .1s,box-shadow .1s;border:none;border-radius:5px;background:0 0;color:#ccc;font-family:serif;font-family:monospace;font-size:2.5em;cursor:pointer;justify-self:end}.swal2-close:hover{transform:none;background:0 0;color:#f27474}.swal2-close:focus{outline:0;box-shadow:inset 0 0 0 3px rgba(100,150,200,.5)}.swal2-close::-moz-focus-inner{border:0}.swal2-html-container{z-index:1;justify-content:center;margin:1em 1.6em .3em;padding:0;overflow:auto;color:inherit;font-size:1.125em;font-weight:400;line-height:normal;text-align:center;word-wrap:break-word;word-break:break-word}.swal2-checkbox,.swal2-file,.swal2-input,.swal2-radio,.swal2-select,.swal2-textarea{margin:1em 2em 3px}.swal2-file,.swal2-input,.swal2-textarea{box-sizing:border-box;width:auto;transition:border-color .1s,box-shadow .1s;border:1px solid #d9d9d9;border-radius:.1875em;background:inherit;box-shadow:inset 0 1px 1px rgba(0,0,0,.06),0 0 0 3px transparent;color:inherit;font-size:1.125em}.swal2-file.swal2-inputerror,.swal2-input.swal2-inputerror,.swal2-textarea.swal2-inputerror{border-color:#f27474!important;box-shadow:0 0 2px #f27474!important}.swal2-file:focus,.swal2-input:focus,.swal2-textarea:focus{border:1px solid #b4dbed;outline:0;box-shadow:inset 0 1px 1px rgba(0,0,0,.06),0 0 0 3px rgba(100,150,200,.5)}.swal2-file::-moz-placeholder,.swal2-input::-moz-placeholder,.swal2-textarea::-moz-placeholder{color:#ccc}.swal2-file:-ms-input-placeholder,.swal2-input:-ms-input-placeholder,.swal2-textarea:-ms-input-placeholder{color:#ccc}.swal2-file::placeholder,.swal2-input::placeholder,.swal2-textarea::placeholder{color:#ccc}.swal2-range{margin:1em 2em 3px;background:#fff}.swal2-range input{width:80%}.swal2-range output{width:20%;color:inherit;font-weight:600;text-align:center}.swal2-range input,.swal2-range output{height:2.625em;padding:0;font-size:1.125em;line-height:2.625em}.swal2-input{height:2.625em;padding:0 .75em}.swal2-file{width:75%;margin-right:auto;margin-left:auto;background:inherit;font-size:1.125em}.swal2-textarea{height:6.75em;padding:.75em}.swal2-select{min-width:50%;max-width:100%;padding:.375em .625em;background:inherit;color:inherit;font-size:1.125em}.swal2-checkbox,.swal2-radio{align-items:center;justify-content:center;background:#fff;color:inherit}.swal2-checkbox label,.swal2-radio label{margin:0 .6em;font-size:1.125em}.swal2-checkbox input,.swal2-radio input{flex-shrink:0;margin:0 .4em}.swal2-input-label{display:flex;justify-content:center;margin:1em auto 0}.swal2-validation-message{align-items:center;justify-content:center;margin:1em 0 0;padding:.625em;overflow:hidden;background:#f0f0f0;color:#666;font-size:1em;font-weight:300}.swal2-validation-message::before{content:"!";display:inline-block;width:1.5em;min-width:1.5em;height:1.5em;margin:0 .625em;border-radius:50%;background-color:#f27474;color:#fff;font-weight:600;line-height:1.5em;text-align:center}.swal2-icon{position:relative;box-sizing:content-box;justify-content:center;width:5em;height:5em;margin:2.5em auto .6em;border:.25em solid transparent;border-radius:50%;border-color:#000;font-family:inherit;line-height:5em;cursor:default;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:3.75em}.swal2-icon.swal2-error{border-color:#f27474;color:#f27474}.swal2-icon.swal2-error .swal2-x-mark{position:relative;flex-grow:1}.swal2-icon.swal2-error [class^=swal2-x-mark-line]{display:block;position:absolute;top:2.3125em;width:2.9375em;height:.3125em;border-radius:.125em;background-color:#f27474}.swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:1.0625em;transform:rotate(45deg)}.swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:1em;transform:rotate(-45deg)}.swal2-icon.swal2-error.swal2-icon-show{-webkit-animation:swal2-animate-error-icon .5s;animation:swal2-animate-error-icon .5s}.swal2-icon.swal2-error.swal2-icon-show .swal2-x-mark{-webkit-animation:swal2-animate-error-x-mark .5s;animation:swal2-animate-error-x-mark .5s}.swal2-icon.swal2-warning{border-color:#facea8;color:#f8bb86}.swal2-icon.swal2-warning.swal2-icon-show{-webkit-animation:swal2-animate-error-icon .5s;animation:swal2-animate-error-icon .5s}.swal2-icon.swal2-warning.swal2-icon-show .swal2-icon-content{-webkit-animation:swal2-animate-i-mark .5s;animation:swal2-animate-i-mark .5s}.swal2-icon.swal2-info{border-color:#9de0f6;color:#3fc3ee}.swal2-icon.swal2-info.swal2-icon-show{-webkit-animation:swal2-animate-error-icon .5s;animation:swal2-animate-error-icon .5s}.swal2-icon.swal2-info.swal2-icon-show .swal2-icon-content{-webkit-animation:swal2-animate-i-mark .8s;animation:swal2-animate-i-mark .8s}.swal2-icon.swal2-question{border-color:#c9dae1;color:#87adbd}.swal2-icon.swal2-question.swal2-icon-show{-webkit-animation:swal2-animate-error-icon .5s;animation:swal2-animate-error-icon .5s}.swal2-icon.swal2-question.swal2-icon-show .swal2-icon-content{-webkit-animation:swal2-animate-question-mark .8s;animation:swal2-animate-question-mark .8s}.swal2-icon.swal2-success{border-color:#a5dc86;color:#a5dc86}.swal2-icon.swal2-success [class^=swal2-success-circular-line]{position:absolute;width:3.75em;height:7.5em;transform:rotate(45deg);border-radius:50%}.swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=left]{top:-.4375em;left:-2.0635em;transform:rotate(-45deg);transform-origin:3.75em 3.75em;border-radius:7.5em 0 0 7.5em}.swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=right]{top:-.6875em;left:1.875em;transform:rotate(-45deg);transform-origin:0 3.75em;border-radius:0 7.5em 7.5em 0}.swal2-icon.swal2-success .swal2-success-ring{position:absolute;z-index:2;top:-.25em;left:-.25em;box-sizing:content-box;width:100%;height:100%;border:.25em solid rgba(165,220,134,.3);border-radius:50%}.swal2-icon.swal2-success .swal2-success-fix{position:absolute;z-index:1;top:.5em;left:1.625em;width:.4375em;height:5.625em;transform:rotate(-45deg)}.swal2-icon.swal2-success [class^=swal2-success-line]{display:block;position:absolute;z-index:2;height:.3125em;border-radius:.125em;background-color:#a5dc86}.swal2-icon.swal2-success [class^=swal2-success-line][class$=tip]{top:2.875em;left:.8125em;width:1.5625em;transform:rotate(45deg)}.swal2-icon.swal2-success [class^=swal2-success-line][class$=long]{top:2.375em;right:.5em;width:2.9375em;transform:rotate(-45deg)}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-line-tip{-webkit-animation:swal2-animate-success-line-tip .75s;animation:swal2-animate-success-line-tip .75s}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-line-long{-webkit-animation:swal2-animate-success-line-long .75s;animation:swal2-animate-success-line-long .75s}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-circular-line-right{-webkit-animation:swal2-rotate-success-circular-line 4.25s ease-in;animation:swal2-rotate-success-circular-line 4.25s ease-in}.swal2-progress-steps{flex-wrap:wrap;align-items:center;max-width:100%;margin:1.25em auto;padding:0;background:inherit;font-weight:600}.swal2-progress-steps li{display:inline-block;position:relative}.swal2-progress-steps .swal2-progress-step{z-index:20;flex-shrink:0;width:2em;height:2em;border-radius:2em;background:#2778c4;color:#fff;line-height:2em;text-align:center}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step{background:#2778c4}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step{background:#add8e6;color:#fff}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step-line{background:#add8e6}.swal2-progress-steps .swal2-progress-step-line{z-index:10;flex-shrink:0;width:2.5em;height:.4em;margin:0 -1px;background:#2778c4}[class^=swal2]{-webkit-tap-highlight-color:transparent}.swal2-show{-webkit-animation:swal2-show .3s;animation:swal2-show .3s}.swal2-hide{-webkit-animation:swal2-hide .15s forwards;animation:swal2-hide .15s forwards}.swal2-noanimation{transition:none}.swal2-scrollbar-measure{position:absolute;top:-9999px;width:50px;height:50px;overflow:scroll}.swal2-rtl .swal2-close{margin-right:initial;margin-left:0}.swal2-rtl .swal2-timer-progress-bar{right:0;left:auto}@-webkit-keyframes swal2-toast-show{0%{transform:translateY(-.625em) rotateZ(2deg)}33%{transform:translateY(0) rotateZ(-2deg)}66%{transform:translateY(.3125em) rotateZ(2deg)}100%{transform:translateY(0) rotateZ(0)}}@keyframes swal2-toast-show{0%{transform:translateY(-.625em) rotateZ(2deg)}33%{transform:translateY(0) rotateZ(-2deg)}66%{transform:translateY(.3125em) rotateZ(2deg)}100%{transform:translateY(0) rotateZ(0)}}@-webkit-keyframes swal2-toast-hide{100%{transform:rotateZ(1deg);opacity:0}}@keyframes swal2-toast-hide{100%{transform:rotateZ(1deg);opacity:0}}@-webkit-keyframes swal2-toast-animate-success-line-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@keyframes swal2-toast-animate-success-line-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@-webkit-keyframes swal2-toast-animate-success-line-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}@keyframes swal2-toast-animate-success-line-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}@-webkit-keyframes swal2-show{0%{transform:scale(.7)}45%{transform:scale(1.05)}80%{transform:scale(.95)}100%{transform:scale(1)}}@keyframes swal2-show{0%{transform:scale(.7)}45%{transform:scale(1.05)}80%{transform:scale(.95)}100%{transform:scale(1)}}@-webkit-keyframes swal2-hide{0%{transform:scale(1);opacity:1}100%{transform:scale(.5);opacity:0}}@keyframes swal2-hide{0%{transform:scale(1);opacity:1}100%{transform:scale(.5);opacity:0}}@-webkit-keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.8125em;width:1.5625em}}@keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.8125em;width:1.5625em}}@-webkit-keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@-webkit-keyframes swal2-rotate-success-circular-line{0%{transform:rotate(-45deg)}5%{transform:rotate(-45deg)}12%{transform:rotate(-405deg)}100%{transform:rotate(-405deg)}}@keyframes swal2-rotate-success-circular-line{0%{transform:rotate(-45deg)}5%{transform:rotate(-45deg)}12%{transform:rotate(-405deg)}100%{transform:rotate(-405deg)}}@-webkit-keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;transform:scale(.4);opacity:0}50%{margin-top:1.625em;transform:scale(.4);opacity:0}80%{margin-top:-.375em;transform:scale(1.15)}100%{margin-top:0;transform:scale(1);opacity:1}}@keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;transform:scale(.4);opacity:0}50%{margin-top:1.625em;transform:scale(.4);opacity:0}80%{margin-top:-.375em;transform:scale(1.15)}100%{margin-top:0;transform:scale(1);opacity:1}}@-webkit-keyframes swal2-animate-error-icon{0%{transform:rotateX(100deg);opacity:0}100%{transform:rotateX(0);opacity:1}}@keyframes swal2-animate-error-icon{0%{transform:rotateX(100deg);opacity:0}100%{transform:rotateX(0);opacity:1}}@-webkit-keyframes swal2-rotate-loading{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}@keyframes swal2-rotate-loading{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}@-webkit-keyframes swal2-animate-question-mark{0%{transform:rotateY(-360deg)}100%{transform:rotateY(0)}}@keyframes swal2-animate-question-mark{0%{transform:rotateY(-360deg)}100%{transform:rotateY(0)}}@-webkit-keyframes swal2-animate-i-mark{0%{transform:rotateZ(45deg);opacity:0}25%{transform:rotateZ(-25deg);opacity:.4}50%{transform:rotateZ(15deg);opacity:.8}75%{transform:rotateZ(-5deg);opacity:1}100%{transform:rotateX(0);opacity:1}}@keyframes swal2-animate-i-mark{0%{transform:rotateZ(45deg);opacity:0}25%{transform:rotateZ(-25deg);opacity:.4}50%{transform:rotateZ(15deg);opacity:.8}75%{transform:rotateZ(-5deg);opacity:1}100%{transform:rotateX(0);opacity:1}}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow:hidden}body.swal2-height-auto{height:auto!important}body.swal2-no-backdrop .swal2-container{background-color:transparent!important;pointer-events:none}body.swal2-no-backdrop .swal2-container .swal2-popup{pointer-events:all}body.swal2-no-backdrop .swal2-container .swal2-modal{box-shadow:0 0 10px rgba(0,0,0,.4)}@media print{body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow-y:scroll!important}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown)>[aria-hidden=true]{display:none}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) .swal2-container{position:static!important}}body.swal2-toast-shown .swal2-container{box-sizing:border-box;width:360px;max-width:100%;background-color:transparent;pointer-events:none}body.swal2-toast-shown .swal2-container.swal2-top{top:0;right:auto;bottom:auto;left:50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-top-end,body.swal2-toast-shown .swal2-container.swal2-top-right{top:0;right:0;bottom:auto;left:auto}body.swal2-toast-shown .swal2-container.swal2-top-left,body.swal2-toast-shown .swal2-container.swal2-top-start{top:0;right:auto;bottom:auto;left:0}body.swal2-toast-shown .swal2-container.swal2-center-left,body.swal2-toast-shown .swal2-container.swal2-center-start{top:50%;right:auto;bottom:auto;left:0;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-center{top:50%;right:auto;bottom:auto;left:50%;transform:translate(-50%,-50%)}body.swal2-toast-shown .swal2-container.swal2-center-end,body.swal2-toast-shown .swal2-container.swal2-center-right{top:50%;right:0;bottom:auto;left:auto;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-left,body.swal2-toast-shown .swal2-container.swal2-bottom-start{top:auto;right:auto;bottom:0;left:0}body.swal2-toast-shown .swal2-container.swal2-bottom{top:auto;right:auto;bottom:0;left:50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-end,body.swal2-toast-shown .swal2-container.swal2-bottom-right{top:auto;right:0;bottom:0;left:auto}</style>
    <script type="text/javascript" src="https://checkout.razorpay.com/v1/checkout.js?ver=6.7.2" id="cf7rzp-rzp-checkout-js"></script>
    <script type="text/javascript" id="cf7rzp-main-js-extra">
    /* <![CDATA[ */
    var ajax_object_cf7rzp = {"ajax_url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin-ajax.php"};
    /* ]]> */
    </script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/plugins/integrate-razorpay-contact-form-7/assets/js/main.js?ver=1" id="cf7rzp-main-js"></script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/plugins/multiline-files-for-contact-form-7/js/zl-multine-files.js?ver=6.7.2" id="mfcf7_zl_multiline_files_script-js"></script>
    <link rel="https://api.w.org/" href="https://santhoshavidhyalaya.com/wp-json/"><link rel="alternate" title="JSON" type="application/json" href="https://santhoshavidhyalaya.com/wp-json/wp/v2/pages/37"><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://santhoshavidhyalaya.com/xmlrpc.php?rsd">
    <meta name="generator" content="WordPress 6.7.2">
    <link rel="canonical" href="https://santhoshavidhyalaya.com/contact-us/">
    <link rel="shortlink" href="https://santhoshavidhyalaya.com/?p=37">
    <link rel="alternate" title="oEmbed (JSON)" type="application/json+oembed" href="https://santhoshavidhyalaya.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fsanthoshavidhyalaya.com%2Fcontact-us%2F">
    <link rel="alternate" title="oEmbed (XML)" type="text/xml+oembed" href="https://santhoshavidhyalaya.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fsanthoshavidhyalaya.com%2Fcontact-us%2F&amp;format=xml">
    <meta name="generator" content="Elementor 3.18.3; features: e_dom_optimization, e_optimized_assets_loading, e_optimized_css_loading, additional_custom_breakpoints, block_editor_assets_optimize, e_image_loading_optimization; settings: css_print_method-external, google_font-enabled, font_display-auto">
    <meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress.">
    <link rel="icon" href="https://santhoshavidhyalaya.com/wp-content/uploads/2024/04/cropped-Santhosha_Vidhyalaya_Logo_Final_-scaled-1-32x32.jpg" sizes="32x32">
    <link rel="icon" href="https://santhoshavidhyalaya.com/wp-content/uploads/2024/04/cropped-Santhosha_Vidhyalaya_Logo_Final_-scaled-1-192x192.jpg" sizes="192x192">
    <link rel="apple-touch-icon" href="https://santhoshavidhyalaya.com/wp-content/uploads/2024/04/cropped-Santhosha_Vidhyalaya_Logo_Final_-scaled-1-180x180.jpg">
    <meta name="msapplication-TileImage" content="https://santhoshavidhyalaya.com/wp-content/uploads/2024/04/cropped-Santhosha_Vidhyalaya_Logo_Final_-scaled-1-270x270.jpg">
          
    </head>
    <body class="home page-template-default page page-id-2039 gdlr-core-body woocommerce-no-js tribe-no-js kingster-body kingster-body-front kingster-full  kingster-with-sticky-navigation  kingster-blockquote-style-1 gdlr-core-link-to-lightbox dialog-body dialog-buttons-body dialog-container dialog-buttons-container"><div class="kingster-mm-menu-wrap kingster-navigation-font mm-menu mm-pagedim-black mm-offcanvas mm-right" id="kingster-mobile-menu" data-slide="right"><div class="mm-panels"><div class="mm-panel mm-hasnavbar mm-opened mm-current" id="menu-main-navigation"><div class="mm-navbar"><a class="mm-title"><span class="mmenu-custom-close"></span></a></div><ul class="m-menu  mm-listview"><li id="menu-item-119" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-119"><a href="https://santhoshavidhyalaya.com/" class="page-scroll scroll">Home</a></li>
    <li id="menu-item-166" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-166"><a href="https://santhoshavidhyalaya.com/about/" class="page-scroll scroll">About</a></li>
    <li id="menu-item-116" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-116"><a class="mm-next mm-fullsubopen" href="#mm-1" data-target="#mm-1"></a><span class="kingster-mm-menu-blank">Academics</span>
    
    </li>
    <li id="menu-item-236" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-236"><a class="mm-next" href="#mm-2" data-target="#mm-2"></a><a href="https://santhoshavidhyalaya.com/facilities/" class="page-scroll scroll">Facilities</a>
    
    </li>
    <li id="menu-item-161" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-161"><a class="mm-next mm-fullsubopen" href="#mm-3" data-target="#mm-3"></a><span class="kingster-mm-menu-blank">Awards and Recognitions</span>
    
    </li>
    <li id="menu-item-157" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-157"><a class="mm-next mm-fullsubopen" href="#mm-4" data-target="#mm-4"></a><span class="kingster-mm-menu-blank">Admission</span>
    
    </li>
    <li id="menu-item-484" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-484"><a href="https://santhoshavidhyalaya.com/gallery-3/" class="page-scroll scroll">Gallery</a></li>
    <li id="menu-item-143" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-37 current_page_item menu-item-143"><a href="https://santhoshavidhyalaya.com/contact-us/" aria-current="page" class="page-scroll scroll">Contact Us</a></li>
    </ul></div><div class="mm-panel mm-hasnavbar mm-hidden" id="mm-1"><div class="mm-navbar"><a class="mm-btn mm-prev" href="#menu-main-navigation" data-target="#menu-main-navigation"></a><a class="mm-title" href="#menu-main-navigation">Academics</a></div><ul class="sub-menu mm-listview">
        <li id="menu-item-117" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-117"><a href="https://santhoshavidhyalaya.com/affiliations/" class="page-scroll scroll">Affiliations</a></li>
        <li id="menu-item-118" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-118"><a href="https://santhoshavidhyalaya.com/syllabus/" class="page-scroll scroll">Syllabus</a></li>
        <li id="menu-item-281" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-281"><a href="https://santhoshavidhyalaya.com/primary/" class="page-scroll scroll">Primary</a></li>
        <li id="menu-item-282" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-282"><a href="https://www.santhoshavidhyalaya.com/primary/#secondary" class="page-scroll scroll">Secondary</a></li>
        <li id="menu-item-283" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-283"><a href="https://www.santhoshavidhyalaya.com/primary/#higher-secondary" class="page-scroll scroll">Higher Secondary</a></li>
        <li id="menu-item-289" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-289"><a href="https://santhoshavidhyalaya.com/khan-academy/" class="page-scroll scroll">Khan Academy</a></li>
        <li id="menu-item-120" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-120"><a href="https://santhoshavidhyalaya.com/cca-programme/" class="page-scroll scroll">CCA Programme</a></li>
    </ul></div><div class="mm-panel mm-hasnavbar mm-hidden" id="mm-2"><div class="mm-navbar"><a class="mm-btn mm-prev" href="#menu-main-navigation" data-target="#menu-main-navigation"></a><a class="mm-title" href="#menu-main-navigation">Facilities</a></div><ul class="sub-menu mm-listview">
        <li id="menu-item-244" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-244"><a href="https://www.santhoshavidhyalaya.com/facilities/#chapel" class="page-scroll scroll">Chapel</a></li>
        <li id="menu-item-245" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-245"><a href="https://www.santhoshavidhyalaya.com/facilities/#auditorium" class="page-scroll scroll">Auditorium</a></li>
        <li id="menu-item-246" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-246"><a href="https://www.santhoshavidhyalaya.com/facilities/#library" class="page-scroll scroll">Library</a></li>
        <li id="menu-item-247" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-247"><a href="https://www.santhoshavidhyalaya.com/facilities/#digital-resource-centre" class="page-scroll scroll">Digital Resource Centre</a></li>
        <li id="menu-item-248" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-248"><a href="https://www.santhoshavidhyalaya.com/facilities/#science-laboratories" class="page-scroll scroll">Science Laboratories</a></li>
        <li id="menu-item-249" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-249"><a href="https://www.santhoshavidhyalaya.com/facilities/#smart-classrooms" class="page-scroll scroll">Smart Classrooms</a></li>
        <li id="menu-item-250" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-250"><a href="https://www.santhoshavidhyalaya.com/facilities/#sports-and-games" class="page-scroll scroll">Sports and Games</a></li>
        <li id="menu-item-251" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-251"><a href="https://www.santhoshavidhyalaya.com/facilities/#music" class="page-scroll scroll">Music</a></li>
        <li id="menu-item-252" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-252"><a href="https://www.santhoshavidhyalaya.com/facilities/#hostel" class="page-scroll scroll">Hostel</a></li>
        <li id="menu-item-253" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-253"><a href="https://www.santhoshavidhyalaya.com/facilities/#medical-care" class="page-scroll scroll">Medical Care</a></li>
        <li id="menu-item-254" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-254"><a href="https://www.santhoshavidhyalaya.com/facilities/#club-activities" class="page-scroll scroll">Club Activities</a></li>
        <li id="menu-item-255" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-255"><a href="https://www.santhoshavidhyalaya.com/facilities/#student-leadership" class="page-scroll scroll">Student Leadership</a></li>
        <li id="menu-item-257" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-257"><a href="https://www.santhoshavidhyalaya.com/facilities/#solar-power" class="page-scroll scroll">Solar Power</a></li>
        <li id="menu-item-258" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-258"><a href="https://www.santhoshavidhyalaya.com/facilities/#generators" class="page-scroll scroll">Generators</a></li>
    </ul></div><div class="mm-panel mm-hasnavbar mm-hidden" id="mm-3"><div class="mm-navbar"><a class="mm-btn mm-prev" href="#menu-main-navigation" data-target="#menu-main-navigation"></a><a class="mm-title" href="#menu-main-navigation">Awards and Recognitions</a></div><ul class="sub-menu mm-listview">
        <li id="menu-item-162" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-162"><a href="https://santhoshavidhyalaya.com/awards/" class="page-scroll scroll">Awards</a></li>
    </ul></div><div class="mm-panel mm-hasnavbar mm-hidden" id="mm-4"><div class="mm-navbar"><a class="mm-btn mm-prev" href="#menu-main-navigation" data-target="#menu-main-navigation"></a><a class="mm-title" href="#menu-main-navigation">Admission</a></div><ul class="sub-menu mm-listview">
        <li id="menu-item-160" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-160"><a href="https://santhoshavidhyalaya.com/academic-calendar/" class="page-scroll scroll">Academic Calendar</a></li>
        <li id="menu-item-159" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-159"><a href="https://santhoshavidhyalaya.com/admission-procedure/" class="page-scroll scroll">Admission Procedure</a></li>
        <li id="menu-item-158" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-158"><a href="https://santhoshavidhyalaya.com/school-and-hostel-fees/" class="page-scroll scroll">School and Hostel Fees</a></li>
    </ul></div></div></div>
        <div class="kingster-mobile-header-wrap">
            <div class="kingster-mobile-header kingster-header-background kingster-style-slide kingster-sticky-mobile-navigation " id="kingster-mobile-header">
                <div class="kingster-mobile-header-container kingster-container clearfix">
                    <div class="kingster-logo  kingster-item-pdlr">
                        <div class="kingster-logo-inner">
                            <a href="https://santhoshavidhyalaya.com" class=""><img src="https://santhoshavidhyalaya.com/wp-content/uploads/2024/04/SV-Logo-PNG.png" alt=""></a>
                        </div>
                    </div>
                    <div class="kingster-mobile-menu-right">
                        <div class="kingster-mobile-menu"><a class="kingster-mm-menu-button kingster-mobile-menu-button kingster-mobile-button-hamburger" href="#kingster-mobile-menu"><span></span></a>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="kingster-body-outer-wrapper  mm-page mm-slideout" id="mm-0">
            <div class="kingster-body-wrapper clearfix  kingster-with-frame">
                <div class="kingster-top-bar">
                    <div class="kingster-top-bar-background"></div>
                    <div class="kingster-top-bar-container kingster-container ">
                        <div class="kingster-top-bar-container-inner clearfix">
                            <div class="kingster-top-bar-left kingster-item-pdlr">
                                <i class="fa fa-envelope-open-o" id="i_fd84_0"></i> <a href="mailto:info@santhoshavidhyalaya.com ">info@santhoshavidhyalaya.com  </a> / <a href="mailto: ">                             
                                <i class="fa fa-phone" id="i_fd84_1"></i> </a><a href="tel:+91 80125 12100">+91 80125 12100</a> / <a href="tel:+91 80125 12100">+91 80125 12100</a>
                            </div>
                                <div class="kingster-copyright-right kingster-item-pdlr">
                                <div class="gdlr-core-social-network-item gdlr-core-item-pdb  gdlr-core-none-align" id="div_1dd7_112">
                                    <a href="https://www.facebook.com/svdohnavur" target="_blank" class="gdlr-core-social-network-icon" title="facebook">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                    <a href="https://www.youtube.com/c/SanthoshaVidhyalaya" target="_blank" class="gdlr-core-social-network-icon" title="google-plus">
                                        <i class="fa fa-youtube"></i>
                                    </a>
                                    <a href="https://www.instagram.com/svdohnavur/" target="_blank" class="gdlr-core-social-network-icon" title="instagram">
                                        <i class="fa fa-instagram"></i>
                                    </a>
                                </div>
                            </div>
                                
                        </div>
                    </div>
                </div>
                <header class="kingster-header-wrap kingster-header-style-plain  kingster-style-menu-right kingster-sticky-navigation kingster-style-fixed" data-navigation-offset="75px" style="">
                    <div class="kingster-header-background"></div>
                    <div class="kingster-header-container  kingster-container">
                        <div class="kingster-header-container-inner clearfix">
                            <div class="kingster-logo  kingster-item-pdlr">
                                <div class="kingster-logo-inner">
                                    <a class="" href="https://santhoshavidhyalaya.com"><img src="https://santhoshavidhyalaya.com/wp-content/uploads/2024/04/SV-Logo-PNG.png" alt=""></a>
                                </div>
                            </div>
                            <div class="kingster-navigation kingster-item-pdlr clearfix ">
                                <div class="kingster-main-menu sf-js-enabled sf-arrows" id="kingster-main-menu" style="touch-action: pan-y;">
                                        <ul id="menu-home-menu" class="sf-menu "><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-119"><a href="https://santhoshavidhyalaya.com/" class="page-scroll scroll">Home</a></li>
    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-166"><a href="https://santhoshavidhyalaya.com/about/" class="page-scroll scroll">About</a></li>
    <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-116"><a href="#" class="page-scroll scroll sf-with-ul">Academics</a>
    <ul class="sub-menu" style="display: none;">
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-117"><a href="https://santhoshavidhyalaya.com/affiliations/" class="page-scroll scroll">Affiliations</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-118"><a href="https://santhoshavidhyalaya.com/syllabus/" class="page-scroll scroll">Syllabus</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-281"><a href="https://santhoshavidhyalaya.com/primary/" class="page-scroll scroll">Primary</a></li>
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-282"><a href="https://www.santhoshavidhyalaya.com/primary/#secondary" class="page-scroll scroll">Secondary</a></li>
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-283"><a href="https://www.santhoshavidhyalaya.com/primary/#higher-secondary" class="page-scroll scroll">Higher Secondary</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-289"><a href="https://santhoshavidhyalaya.com/khan-academy/" class="page-scroll scroll">Khan Academy</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-120"><a href="https://santhoshavidhyalaya.com/cca-programme/" class="page-scroll scroll">CCA Programme</a></li>
    </ul>
    </li>
    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-236"><a href="https://santhoshavidhyalaya.com/facilities/" class="page-scroll scroll sf-with-ul">Facilities</a>
    <ul class="sub-menu" style="display: none;">
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-244"><a href="https://www.santhoshavidhyalaya.com/facilities/#chapel" class="page-scroll scroll">Chapel</a></li>
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-245"><a href="https://www.santhoshavidhyalaya.com/facilities/#auditorium" class="page-scroll scroll">Auditorium</a></li>
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-246"><a href="https://www.santhoshavidhyalaya.com/facilities/#library" class="page-scroll scroll">Library</a></li>
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-247"><a href="https://www.santhoshavidhyalaya.com/facilities/#digital-resource-centre" class="page-scroll scroll">Digital Resource Centre</a></li>
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-248"><a href="https://www.santhoshavidhyalaya.com/facilities/#science-laboratories" class="page-scroll scroll">Science Laboratories</a></li>
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-249"><a href="https://www.santhoshavidhyalaya.com/facilities/#smart-classrooms" class="page-scroll scroll">Smart Classrooms</a></li>
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-250"><a href="https://www.santhoshavidhyalaya.com/facilities/#sports-and-games" class="page-scroll scroll">Sports and Games</a></li>
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-251"><a href="https://www.santhoshavidhyalaya.com/facilities/#music" class="page-scroll scroll">Music</a></li>
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-252"><a href="https://www.santhoshavidhyalaya.com/facilities/#hostel" class="page-scroll scroll">Hostel</a></li>
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-253"><a href="https://www.santhoshavidhyalaya.com/facilities/#medical-care" class="page-scroll scroll">Medical Care</a></li>
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-254"><a href="https://www.santhoshavidhyalaya.com/facilities/#club-activities" class="page-scroll scroll">Club Activities</a></li>
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-255"><a href="https://www.santhoshavidhyalaya.com/facilities/#student-leadership" class="page-scroll scroll">Student Leadership</a></li>
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-257"><a href="https://www.santhoshavidhyalaya.com/facilities/#solar-power" class="page-scroll scroll">Solar Power</a></li>
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-258"><a href="https://www.santhoshavidhyalaya.com/facilities/#generators" class="page-scroll scroll">Generators</a></li>
    </ul>
    </li>
    <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-161"><a href="#" class="page-scroll scroll sf-with-ul">Awards and Recognitions</a>
    <ul class="sub-menu" style="display: none;">
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-162"><a href="https://santhoshavidhyalaya.com/awards/" class="page-scroll scroll">Awards</a></li>
    </ul>
    </li>
    <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-157"><a href="#" class="page-scroll scroll sf-with-ul">Admission</a>
    <ul class="sub-menu" style="display: none;">
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-160"><a href="https://santhoshavidhyalaya.com/academic-calendar/" class="page-scroll scroll">Academic Calendar</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-159"><a href="https://santhoshavidhyalaya.com/admission-procedure/" class="page-scroll scroll">Admission Procedure</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-158"><a href="https://santhoshavidhyalaya.com/school-and-hostel-fees/" class="page-scroll scroll">School and Hostel Fees</a></li>
    </ul>
    </li>
    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-484"><a href="https://santhoshavidhyalaya.com/gallery-3/" class="page-scroll scroll">Gallery</a></li>
    <li class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-37 current_page_item menu-item-143"><a href="https://santhoshavidhyalaya.com/contact-us/" aria-current="page" class="page-scroll scroll">Contact Us</a></li>
    </ul>  
                                    <div class="kingster-navigation-slide-bar" id="kingster-navigation-slide-bar" style="width: 92px; left: 1112.9px; display: block; overflow: hidden;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </header> 
    <div class="kingster-page-title-wrap  kingster-style-custom kingster-left-align" id="div_983a_0" style="background-image: url(https://santhoshavidhyalaya.com/wp-content/uploads/2022/04/contact-1.png);">
                    <div class="kingster-header-transparent-substitute"></div>
                    <div class="kingster-page-title-overlay"></div>
                    <div class="kingster-page-title-bottom-gradient"></div>
                    <div class="kingster-page-title-container kingster-container">
                        <div class="kingster-page-title-content kingster-item-pdlr" id="div_983a_1">
                            <div class="kingster-page-caption" id="div_983a_2">Know Us Better</div>
                            <h1 class="kingster-page-title" id="h1_983a_0">Contact Us</h1></div>
                    </div>
                </div>
                <div class="kingster-breadcrumbs">
                    <div class="kingster-breadcrumbs-container kingster-container">
                        <div class="kingster-breadcrumbs-item kingster-item-pdlr"> <span property="itemListElement" typeof="ListItem"><a property="item" typeof="WebPage" title="Go to Kingster." href="https://santhoshavidhyalaya.com" class="home"><span property="name">Home</span></a>
                            <meta property="position" content="1">
                            </span>&gt;<span property="itemListElement" typeof="ListItem"><span property="name">Contact Us</span>
                            <meta property="position" content="2">
                            </span>
                        </div>
                    </div>
                </div>
                        
                        
                    </div>
                </div>
    
                <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Multi-Step Donation Form</title>
  <style>
    body { font-family: Arial, sans-serif; }
    .form-step { display: none; }
    .form-step.active { display: block; }
    .buttons { margin-top: 20px; }
  </style>
</head>
<body>

<form id="donationForm" action="{{ route('submitDonation') }}" method="POST" enctype="multipart/form-data">
  @csrf

  <!-- Step 1: Select Amount & Upload Image -->
  <div class="form-step active" id="step1">
    <h2>Step 1: Select Amount & Upload Image</h2>
    <!-- Uncomment below if you want image upload in future -->
    <!--
    <label>Upload Image:</label>
    <input type="file" id="image" name="image" accept="image/*" required>
    -->
    
    <label>Select Amount:</label>
    <input type="radio" name="amount" value="500"> 500
    <input type="radio" name="amount" value="1000"> 1000
    <input type="radio" name="amount" value="5000"> 5000
    <input type="radio" id="otherAmountRadio" name="amount" value="other"> Other
    <input type="text" id="otherAmount" name="other_amount" placeholder="Enter amount" style="display:none;">

    <div class="buttons">
      <button type="button" onclick="nextStep(1)">Next</button>
    </div>
  </div>

  <!-- Step 2: Enter Donor Details -->
  <div class="form-step" id="step2">
    <h2>Step 2: Enter Your Details</h2>
    <label>Name:</label>
    <input type="text" id="name" name="name" required>

    <label>Email:</label>
    <input type="email" id="email" name="email" required>

    <label>Phone:</label>
    <input type="text" id="phone" name="phone" required>

    <div class="buttons">
      <button type="button" onclick="prevStep(2)">Back</button>
      <button type="button" onclick="nextStep(2)">Next</button>
    </div>
  </div>

  <!-- Step 3: Preview & Submit -->
  <div class="form-step" id="step3">
    <h2>Step 3: Preview & Submit</h2>
    <!-- Uncomment if you decide to preview image details in the future -->
    <!--<p><strong>Image:</strong> <span id="previewImage"></span></p>-->
    <p><strong>Amount:</strong> <span id="previewAmount"></span></p>
    <p><strong>Name:</strong> <span id="previewName"></span></p>
    <p><strong>Email:</strong> <span id="previewEmail"></span></p>
    <p><strong>Phone:</strong> <span id="previewPhone"></span></p>

    <div class="buttons">
      <button type="button" onclick="prevStep(3)">Back</button>
      <button type="button" onclick="submitForm()">Submit</button>
    </div>
  </div>
</form>

<script>
  let currentStep = 1;

  // Move to the next step after validating input
  function nextStep(step) {
    if (step === 1) {
      const selectedAmount = document.querySelector('input[name="amount"]:checked');
      if (!selectedAmount) {
        alert("Please select an amount.");
        return;
      }
      // If "other" is selected, check that the user has entered an amount
      if (selectedAmount.value === "other") {
        const otherAmount = document.getElementById('otherAmount').value;
        if (!otherAmount) {
          alert("Please enter an amount.");
          return;
        }
      }
      // Uncomment below if you want to enforce image upload
      /*
      if (!document.getElementById('image').files.length) {
        alert("Please upload an image.");
        return;
      }
      */
    }
    if (step === 2) {
      if (!document.getElementById('name').value || 
          !document.getElementById('email').value || 
          !document.getElementById('phone').value) {
        alert("Please fill all details.");
        return;
      }
    }
    document.getElementById(`step${step}`).classList.remove('active');
    document.getElementById(`step${step + 1}`).classList.add('active');
    currentStep++;
    updatePreview();
  }

  // Move back to the previous step
  function prevStep(step) {
    document.getElementById(`step${step}`).classList.remove('active');
    document.getElementById(`step${step - 1}`).classList.add('active');
    currentStep--;
  }

  // Update the preview section with current form values
  function updatePreview() {
    const selectedAmount = document.querySelector('input[name="amount"]:checked');
    let amountValue = selectedAmount.value;
    if (amountValue === "other") {
      amountValue = document.getElementById('otherAmount').value;
    }
    document.getElementById('previewAmount').innerText = amountValue;
    document.getElementById('previewName').innerText = document.getElementById('name').value;
    document.getElementById('previewEmail').innerText = document.getElementById('email').value;
    document.getElementById('previewPhone').innerText = document.getElementById('phone').value;
    
    // Uncomment if you want to show image file name in preview
    /*
    const image = document.getElementById('image').files[0];
    if (image) {
      document.getElementById('previewImage').innerText = image.name;
    }
    */
  }

  // Submit the form using fetch API
  function submitForm() {
    const formData = new FormData(document.getElementById('donationForm'));

    fetch("{{ route('submitDonation') }}", {
      method: "POST",
      body: formData,
      headers: {
        "X-CSRF-TOKEN": "{{ csrf_token() }}"
      }
    })
    .then(response => response.json())
    .then(data => {
      alert(data.message);
      // Redirect to Payment Gateway URL or another page based on response
      window.location.href = data.payment_url;
    })
    .catch(error => console.error("Error:", error));
  }

  // Show the "Other Amount" input field when "Other" radio button is selected
  document.getElementById('otherAmountRadio').addEventListener('change', function() {
    document.getElementById('otherAmount').style.display = 'block';
  });
</script>

</body>
</html>

    <footer>
                    <div class="kingster-footer-wrapper ">
                        <div class="kingster-footer-container kingster-container clearfix">
                            <div class="kingster-footer-column kingster-item-pdlr kingster-column-15">
                                <div id="text-2" class="widget widget_text kingster-widget">
                                    <div class="textwidget">
                                        <img src="https://santhoshavidhyalaya.com/wp-content/uploads/2024/04/SV-Logo-PNG.png">
                                        
                                        <p>Address: The Principal, Santhosha Vidhyalaya, Dohnavur – 627102 Tirunelveli Dist. Tamilnadu</p>
                                            
                                            
                                        <p>Mobile: <span id="span_1dd7_11"><a href="tel:+91 80125 12100">+91 80125 12100</a></span></p>
                                        
                                        <p>Mobile: <span id="span_1dd7_11"><a href="tel:+91 80125 12143">+91 80125 12143</a></span></p>
                                        
                                            <p>Principal:<span id="span_1dd7_11"><a href="mailto:principal@santhoshavidhyalaya.com"> principal@santhoshavidhyalaya.com</a></span>
                                             </p>
                                             
                                             <p>School:<span id="span_1dd7_11"><a href="mailto:info@santhoshavidhyalaya.com"> info@santhoshavidhyalaya.com</a></span>
                                             </p>
                                             
                                        <div class="gdlr-core-divider-item gdlr-core-divider-item-normal gdlr-core-left-align">
                                            <div class="gdlr-core-divider-line gdlr-core-skin-divider" id="div_1dd7_111"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="kingster-footer-column kingster-item-pdlr kingster-column-12">
                                <div id="gdlr-core-custom-menu-widget-2" class="widget widget_gdlr-core-custom-menu-widget kingster-widget">
                                    <h3 class="kingster-widget-title">Academics</h3><span class="clear"></span>
                                    <div class="menu-our-campus-container">
                                        
                                        <ul id="menu-our-campus" class="gdlr-core-custom-menu-widget gdlr-core-menu-style-plain"><li id="menu-item-212" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-212"><a href="https://santhoshavidhyalaya.com/affiliations/" class="page-scroll scroll">Affiliations</a></li>
    <li id="menu-item-213" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-213"><a href="https://santhoshavidhyalaya.com/cca-programme/" class="page-scroll scroll">CCA Programme</a></li>
    <li id="menu-item-220" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-220"><a href="https://santhoshavidhyalaya.com/syllabus/" class="page-scroll scroll">Syllabus</a></li>
    </ul> 
    
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="kingster-footer-column kingster-item-pdlr kingster-column-20">
                                <div id="gdlr-core-custom-menu-widget-3" class="widget widget_gdlr-core-custom-menu-widget kingster-widget">
                                    <h3 class="kingster-widget-title">Facilities</h3><span class="clear"></span>
                                    <div class="menu-campus-life-container">
                                        
                                        <ul id="menu-our-campus" class="gdlr-core-custom-menu-widget gdlr-core-menu-style-plain facilities"><li id="menu-item-259" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-259"><a href="https://www.santhoshavidhyalaya.com/facilities/#chapel" class="page-scroll scroll">Chapel</a></li>
    <li id="menu-item-260" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-260"><a href="https://www.santhoshavidhyalaya.com/facilities/#auditorium" class="page-scroll scroll">Auditorium</a></li>
    <li id="menu-item-261" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-261"><a href="https://www.santhoshavidhyalaya.com/facilities/#library" class="page-scroll scroll">Library</a></li>
    <li id="menu-item-262" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-262"><a href="https://www.santhoshavidhyalaya.com/facilities/#digital-resource-centre" class="page-scroll scroll">Digital Resource Centre</a></li>
    <li id="menu-item-263" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-263"><a href="https://www.santhoshavidhyalaya.com/facilities/#science-laboratories" class="page-scroll scroll">Science Laboratories</a></li>
    <li id="menu-item-264" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-264"><a href="https://www.santhoshavidhyalaya.com/facilities/#smart-classrooms" class="page-scroll scroll">Smart Classrooms</a></li>
    <li id="menu-item-265" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-265"><a href="https://www.santhoshavidhyalaya.com/facilities/#sports-and-games" class="page-scroll scroll">Sports and Games</a></li>
    <li id="menu-item-266" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-266"><a href="https://www.santhoshavidhyalaya.com/facilities/#music" class="page-scroll scroll">Music</a></li>
    <li id="menu-item-267" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-267"><a href="https://www.santhoshavidhyalaya.com/facilities/#hostel" class="page-scroll scroll">Hostel</a></li>
    <li id="menu-item-268" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-268"><a href="https://www.santhoshavidhyalaya.com/facilities/#medical-care" class="page-scroll scroll">Medical Care</a></li>
    <li id="menu-item-269" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-269"><a href="https://www.santhoshavidhyalaya.com/facilities/#club-activities" class="page-scroll scroll">Club Activities</a></li>
    <li id="menu-item-270" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-270"><a href="https://www.santhoshavidhyalaya.com/facilities/#student-leadership" class="page-scroll scroll">Student Leadership</a></li>
    <li id="menu-item-271" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-271"><a href="https://www.santhoshavidhyalaya.com/facilities/#ro-plants" class="page-scroll scroll">RO plants</a></li>
    <li id="menu-item-272" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-272"><a href="https://www.santhoshavidhyalaya.com/facilities/#solar-power" class="page-scroll scroll">Solar Power</a></li>
    <li id="menu-item-273" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-273"><a href="https://www.santhoshavidhyalaya.com/facilities/#generators" class="page-scroll scroll">Generators</a></li>
    </ul> 
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="kingster-footer-column kingster-item-pdlr kingster-column-12">
                                <div id="gdlr-core-custom-menu-widget-4" class="widget widget_gdlr-core-custom-menu-widget kingster-widget">
                                    <h3 class="kingster-widget-title">Admission</h3><span class="clear"></span>
                                    <div class="menu-academics-container">
                                        <ul id="menu-our-campus" class="gdlr-core-custom-menu-widget gdlr-core-menu-style-plain"><li id="menu-item-194" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-194"><a href="https://santhoshavidhyalaya.com/admission-procedure/" class="page-scroll scroll">Admission Procedure</a></li>
    <li id="menu-item-195" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-195"><a href="https://santhoshavidhyalaya.com/academic-calendar/" class="page-scroll scroll">Academic Calendar</a></li>
    <li id="menu-item-196" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-196"><a href="https://santhoshavidhyalaya.com/school-and-hostel-fees/" class="page-scroll scroll">School and Hostel Fees</a></li>
    </ul> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="kingster-copyright-wrapper">
                        <div class="kingster-copyright-container kingster-container clearfix">
                            <div class="kingster-copyright-left kingster-item-pdlr">Copyright All Right Reserved 2022,Eucto Digital</div>
                            <div class="kingster-copyright-right kingster-item-pdlr">
                                <div class="gdlr-core-social-network-item gdlr-core-item-pdb  gdlr-core-none-align" id="div_1dd7_112">
                                    <a href="https://www.facebook.com/svdohnavur" target="_blank" class="gdlr-core-social-network-icon" title="facebook">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                    <a href="https://www.youtube.com/c/SanthoshaVidhyalaya" target="_blank" class="gdlr-core-social-network-icon" title="google-plus">
                                        <i class="fa fa-youtube"></i>
                                    </a>
                                    <a href="https://www.instagram.com/svdohnavur/" target="_blank" class="gdlr-core-social-network-icon" title="instagram">
                                        <i class="fa fa-instagram"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            
        
    
    
    
    
        <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/js/jquery/jquery.js"></script>
        <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/js/jquery/jquery-migrate.min.js"></script>
        <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js"></script><div class="razorpay-container" style="z-index: 2147483647; position: fixed; top: 0px; display: none; left: 0px; height: 100%; width: 100%; max-height: 100dvh; backface-visibility: hidden; overflow-y: visible;"><style>@keyframes rzp-rot{to{transform: rotate(360deg);}}@-webkit-keyframes rzp-rot{to{-webkit-transform: rotate(360deg);}} .razorpay-container > iframe {min-height: 100%!important;}</style><div class="razorpay-backdrop" style="min-height: 100%; transition: 0.3s ease-out; position: fixed; top: 0px; left: 0px; width: 100%; height: 100%;"><span style="text-decoration: none; background: rgb(214, 68, 68); border: 1px dashed white; padding: 3px; opacity: 0; transform: rotate(45deg); transition: opacity 0.3s ease-in; font-family: lato, ubuntu, helvetica, sans-serif; color: white; position: absolute; width: 200px; text-align: center; right: -50px; top: 50px;">Test Mode</span></div><iframe style="opacity: 1; height: 100%; position: relative; background: none; display: block; border: 0 none transparent; margin: 0px; padding: 0px; z-index: 2;" allowtransparency="true" frameborder="0" width="100%" height="100%" src="https://api.razorpay.com/v1/checkout/public?traffic_env=production&amp;build=dae009764f18df5141fc9f059fcdaea71f82f859&amp;build_v1=ee299240c3eb715600c5e966852d17333ca665e0&amp;checkout_v2=1&amp;new_session=1" class="razorpay-checkout-frame" allow="otp-credentials; payment; clipboard-write; publickey-credentials-get https://api.razorpay.com; publickey-credentials-create 'self' https://api.razorpay.com; camera *"></iframe></div>
        <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/plugins/revslider/public/assets/js/extensions/revolution.extension.slideanims.min.js"></script>
        <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/plugins/revslider/public/assets/js/extensions/revolution.extension.layeranimation.min.js"></script>
        <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/plugins/revslider/public/assets/js/extensions/revolution.extension.kenburn.min.js"></script>
        <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/plugins/revslider/public/assets/js/extensions/revolution.extension.navigation.min.js"></script>
        <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/plugins/revslider/public/assets/js/extensions/revolution.extension.parallax.min.js"></script>  
        <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/plugins/revslider/public/assets/js/extensions/revolution.extension.actions.min.js"></script> 
        <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/plugins/revslider/public/assets/js/extensions/revolution.extension.video.min.js"></script>
    
        <script type="text/javascript">
            /*<![CDATA[*/
            function setREVStartSize(e) {
                try {
                    e.c = jQuery(e.c);
                    var i = jQuery(window).width(),
                        t = 9999,
                        r = 0,
                        n = 0,
                        l = 0,
                        f = 0,
                        s = 0,
                        h = 0;
                    if (e.responsiveLevels && (jQuery.each(e.responsiveLevels, function(e, f) {
                            f > i && (t = r = f, l = e), i > f && f > r && (r = f, n = e)
                        }), t > r && (l = n)), f = e.gridheight[l] || e.gridheight[0] || e.gridheight, s = e.gridwidth[l] || e.gridwidth[0] || e.gridwidth, h = i / s, h = h > 1 ? 1 : h, f = Math.round(h * f), "fullscreen" == e.sliderLayout) {
                        var u = (e.c.width(), jQuery(window).height());
                        if (void 0 != e.fullScreenOffsetContainer) {
                            var c = e.fullScreenOffsetContainer.split(",");
                            if (c) jQuery.each(c, function(e, i) {
                                u = jQuery(i).length > 0 ? u - jQuery(i).outerHeight(!0) : u
                            }), e.fullScreenOffset.split("%").length > 1 && void 0 != e.fullScreenOffset && e.fullScreenOffset.length > 0 ? u -= jQuery(window).height() * parseInt(e.fullScreenOffset, 0) / 100 : void 0 != e.fullScreenOffset && e.fullScreenOffset.length > 0 && (u -= parseInt(e.fullScreenOffset, 0))
                        }
                        f = u
                    } else void 0 != e.minHeight && f < e.minHeight && (f = e.minHeight);
                    e.c.closest(".rev_slider_wrapper").css({
                        height: f
                    })
                } catch (d) {
                    console.log("Failure at Presize of Slider:");
                }
            }; /*]]>*/
        </script>
    
    
    
        <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/plugins/goodlayers-core/plugins/combine/script.js"></script>
        <script type="text/javascript">
            var gdlr_core_pbf = {
                "admin": "",
                "video": {
                    "width": "640",
                    "height": "360"
                },
                "ajax_url": "https:\/\/demo.goodlayers.com\/kingster\/wp-admin\/admin-ajax.php"
            };
        </script>
        <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/plugins/goodlayers-core/include/js/page-builder.js"></script>
        <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/js/jquery/ui/effect.min.js"></script>
        <script type="text/javascript">
            var kingster_script_core = {
                "home_url": "https:\/\/demo.goodlayers.com\/kingster\/"
            };
        </script>
        <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/themes/santhosha%20vidhalaya/js/plugins.min.js"></script>
        <script>
            /*<![CDATA[*/
            var htmlDiv = document.getElementById("rs-plugin-settings-inline-css");
            var htmlDivCss = "";
            if (htmlDiv) {
                htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
            } else {
                var htmlDiv = document.createElement("div");
                htmlDiv.innerHTML = "<style>" + htmlDivCss + "</style>";
                document.getElementsByTagName("head")[0].appendChild(htmlDiv.childNodes[0]);
            } /*]]>*/
        </script>
        <script type="text/javascript">
            /*<![CDATA[*/
            if (setREVStartSize !== undefined) setREVStartSize({
                c: '#rev_slider_1_1',
                gridwidth: [1380],
                gridheight: [713],
                sliderLayout: 'auto'
            });
            var revapi1, tpj;
            (function() {
                if (!/loaded|interactive|complete/.test(document.readyState)) document.addEventListener("DOMContentLoaded", onLoad);
                else onLoad();
    
                function onLoad() {
                    if (tpj === undefined) {
                        tpj = jQuery;
                        if ("off" == "on") tpj.noConflict();
                    }
                    if (tpj("#rev_slider_1_1").revolution == undefined) {
                        revslider_showDoubleJqueryError("#rev_slider_1_1");
                    } else {
                        revapi1 = tpj("#rev_slider_1_1").show().revolution({
                            sliderType: "standard",
                            jsFileLocation: "//demo.goodlayers.com/kingster/wp-content/plugins/revslider/public/assets/js/",
                            sliderLayout: "auto",
                            dottedOverlay: "none",
                            delay: 9000,
                            navigation: {
                                keyboardNavigation: "off",
                                keyboard_direction: "horizontal",
                                mouseScrollNavigation: "off",
                                mouseScrollReverse: "default",
                                onHoverStop: "off",
                                touch: {
                                    touchenabled: "on",
                                    touchOnDesktop: "off",
                                    swipe_threshold: 75,
                                    swipe_min_touches: 1,
                                    swipe_direction: "horizontal",
                                    drag_block_vertical: false
                                },
                                arrows: {
                                    style: "uranus",
                                    enable: true,
                                    hide_onmobile: true,
                                    hide_under: 1500,
                                    hide_onleave: true,
                                    hide_delay: 200,
                                    hide_delay_mobile: 1200,
                                    tmp: '',
                                    left: {
                                        h_align: "left",
                                        v_align: "center",
                                        h_offset: 20,
                                        v_offset: 0
                                    },
                                    right: {
                                        h_align: "right",
                                        v_align: "center",
                                        h_offset: 20,
                                        v_offset: 0
                                    }
                                },
                                bullets: {
                                    enable: true,
                                    hide_onmobile: false,
                                    hide_over: 1499,
                                    style: "uranus",
                                    hide_onleave: true,
                                    hide_delay: 200,
                                    hide_delay_mobile: 1200,
                                    direction: "horizontal",
                                    h_align: "center",
                                    v_align: "bottom",
                                    h_offset: 0,
                                    v_offset: 30,
                                    space: 7,
                                    tmp: '<span class="tp-bullet-inner"></span>'
                                }
                            },
                            visibilityLevels: [1240, 1024, 778, 480],
                            gridwidth: 1380,
                            gridheight: 713,
                            lazyType: "none",
                            shadow: 0,
                            spinner: "off",
                            stopLoop: "off",
                            stopAfterLoops: -1,
                            stopAtSlide: -1,
                            shuffle: "off",
                            autoHeight: "off",
                            disableProgressBar: "on",
                            hideThumbsOnMobile: "off",
                            hideSliderAtLimit: 0,
                            hideCaptionAtLimit: 0,
                            hideAllCaptionAtLilmit: 0,
                            debugMode: false,
                            fallbacks: {
                                simplifyAll: "off",
                                nextSlideOnWindowFocus: "off",
                                disableFocusListener: false,
                            }
                        });
                    };
                };
            }()); /*]]>*/
            
            
            
            document.addEventListener('wpcf7mailsent', function (event) {
        var formId = 'submit-pro';
    
        // Check if the form ID matches
        if (event.detail.contactFormId == formId) {
            // Check if the payment_status field is set to 'success'
            if (event.detail.inputs.payment_status == 'success') {
                // Show the success message or trigger an action
                var responseOutput = document.querySelector('.wpcf7-response-output');
                if (responseOutput) {
                    responseOutput.classList.add('wpcf7-mail-sent-ok');
                }
            }
        }
    }, false);
    
        </script>
    
    
    
    
    <div class="cf7rzp-loader">
        <img src="https://santhoshavidhyalaya.com/wp-content/plugins/integrate-razorpay-contact-form-7/assets/img/loader-cod-trans.gif" alt="loader">
        </div><script type="text/template" id="tmpl-elementor-templates-modal__header">
        <div class="elementor-templates-modal__header__logo-area"></div>
        <div class="elementor-templates-modal__header__menu-area"></div>
        <div class="elementor-templates-modal__header__items-area">
           
            <div id="elementor-template-library-header-tools"></div>
        </div>
    </script>
    
    <script type="text/template" id="tmpl-elementor-templates-modal__header__logo">
        <span class="elementor-templates-modal__header__logo__icon-wrapper e-logo-wrapper">
            <i class="eicon-elementor"></i>
        </span>
    </script>
    <script type="text/template" id="tmpl-elementor-finder">
        <div id="elementor-finder__search">
            <i class="eicon-search" aria-hidden="true"></i>
            <input id="elementor-finder__search__input" placeholder="Type to find anything in Elementor" autocomplete="off">
        </div>
        <div id="elementor-finder__content"></div>
    </script>
    
    <script type="text/template" id="tmpl-elementor-finder-results-container">
        <div id="elementor-finder__no-results">No Results Found</div>
        <div id="elementor-finder__results"></div>
    </script>
    
    <script type="text/template" id="tmpl-elementor-finder__results__category">
        <div class="elementor-finder__results__category__items"></div>
    </script>
   
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.8.6" id="swv-js"></script>
    <script type="text/javascript" id="contact-form-7-js-extra">
    /* <![CDATA[ */
    var wpcf7 = {"api":{"root":"https:\/\/santhoshavidhyalaya.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
    /* ]]> */
    </script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.8.6" id="contact-form-7-js"></script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-includes/js/jquery/ui/mouse.min.js?ver=1.13.3" id="jquery-ui-mouse-js"></script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-includes/js/jquery/ui/draggable.min.js?ver=1.13.3" id="jquery-ui-draggable-js"></script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-includes/js/underscore.min.js?ver=1.13.7" id="underscore-js"></script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-includes/js/backbone.min.js?ver=1.6.0" id="backbone-js"></script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/plugins/elementor/assets/lib/backbone/backbone.marionette.min.js?ver=2.4.5.e1" id="backbone-marionette-js"></script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/plugins/elementor/assets/lib/backbone/backbone.radio.min.js?ver=1.0.4" id="backbone-radio-js"></script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/plugins/elementor/assets/js/common-modules.min.js?ver=3.18.3" id="elementor-common-modules-js"></script>
    <script type="text/javascript" id="elementor-web-cli-js-before">
    /* <![CDATA[ */
    var elementorWebCliConfig = {"isDebug":false,"urls":{"rest":"https:\/\/santhoshavidhyalaya.com\/wp-json\/","assets":"https:\/\/santhoshavidhyalaya.com\/wp-content\/plugins\/elementor\/assets\/"},"nonce":"bc6318c820","version":"3.18.3"};
    var elementorWebCliConfig = {"isDebug":false,"urls":{"rest":"https:\/\/santhoshavidhyalaya.com\/wp-json\/","assets":"https:\/\/santhoshavidhyalaya.com\/wp-content\/plugins\/elementor\/assets\/"},"nonce":"bc6318c820","version":"3.18.3"};
    /* ]]> */
    </script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/plugins/elementor/assets/js/web-cli.min.js?ver=3.18.3" id="elementor-web-cli-js"></script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.9.0" id="elementor-dialog-js"></script>
    <script type="text/javascript" id="wp-api-request-js-extra">
    /* <![CDATA[ */
    var wpApiSettings = {"root":"https:\/\/santhoshavidhyalaya.com\/wp-json\/","nonce":"bc6318c820","versionString":"wp\/v2\/"};
    /* ]]> */
    </script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-includes/js/api-request.min.js?ver=6.7.2" id="wp-api-request-js"></script>
    <script type="text/javascript" id="elementor-dev-tools-js-before">
    /* <![CDATA[ */
    var elementorDevToolsConfig = {"isDebug":false,"urls":{"assets":"https:\/\/santhoshavidhyalaya.com\/wp-content\/plugins\/elementor\/assets\/"},"deprecation":{"soft_notices":[],"soft_version_count":4,"hard_version_count":8,"current_version":"3.18.3"}};
    var elementorDevToolsConfig = {"isDebug":false,"urls":{"assets":"https:\/\/santhoshavidhyalaya.com\/wp-content\/plugins\/elementor\/assets\/"},"deprecation":{"soft_notices":[],"soft_version_count":4,"hard_version_count":8,"current_version":"3.18.3"}};
    var elementorDevToolsConfig = {"isDebug":false,"urls":{"assets":"https:\/\/santhoshavidhyalaya.com\/wp-content\/plugins\/elementor\/assets\/"},"deprecation":{"soft_notices":[],"soft_version_count":4,"hard_version_count":8,"current_version":"3.18.3"}};
    /* ]]> */
    </script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/plugins/elementor/assets/js/dev-tools.min.js?ver=3.18.3" id="elementor-dev-tools-js"></script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-includes/js/dist/hooks.min.js?ver=4d63a3d491d11ffd8ac6" id="wp-hooks-js"></script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
    <script type="text/javascript" id="wp-i18n-js-after">
    /* <![CDATA[ */
    wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
    /* ]]> */
    </script>
    <script type="text/javascript" id="elementor-common-js-before">
    /* <![CDATA[ */
    var elementorCommonConfig = {"version":"3.18.3","isRTL":false,"isDebug":false,"isElementorDebug":false,"activeModules":["ajax","finder","connect","event-tracker"],"experimentalFeatures":{"e_dom_optimization":true,"e_optimized_assets_loading":true,"e_optimized_css_loading":true,"additional_custom_breakpoints":true,"block_editor_assets_optimize":true,"landing-pages":true,"e_image_loading_optimization":true,"e_global_styleguide":true},"urls":{"assets":"https:\/\/santhoshavidhyalaya.com\/wp-content\/plugins\/elementor\/assets\/","rest":"https:\/\/santhoshavidhyalaya.com\/wp-json\/"},"filesUpload":{"unfilteredFiles":false},"library_connect":{"is_connected":false,"subscription_plans":{"free":{"label":null,"promotion_url":null,"color":null},"essential":{"label":"Pro","promotion_url":"https:\/\/elementor.com\/pro\/?utm_source=template-library&utm_medium=wp-dash&utm_campaign=gopro","color":"#92003B"},"essential-oct2023":{"label":"Advanced","promotion_url":"https:\/\/elementor.com\/pro\/?utm_source=template-library&utm_medium=wp-dash&utm_campaign=gopro","color":"#92003B"},"advanced":{"label":"Advanced","promotion_url":"https:\/\/elementor.com\/pro\/?utm_source=template-library&utm_medium=wp-dash&utm_campaign=gopro","color":"#92003B"},"expert":{"label":"Expert","promotion_url":"https:\/\/elementor.com\/pro\/?utm_source=template-library&utm_medium=wp-dash&utm_campaign=gopro","color":"#92003B"},"agency":{"label":"Agency","promotion_url":"https:\/\/elementor.com\/pro\/?utm_source=template-library&utm_medium=wp-dash&utm_campaign=gopro","color":"#92003B"}},"base_access_level":0,"base_access_tier":"free","current_access_level":0,"current_access_tier":"free"},"ajax":{"url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin-ajax.php","nonce":"0079e44fa7"},"finder":{"data":{"edit":{"title":"Edit","dynamic":true,"name":"edit"},"general":{"title":"General","dynamic":false,"items":{"saved-templates":{"title":"Saved Templates","icon":"library-save","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/edit.php?post_type=elementor_library&tabs_group=library","keywords":["template","section","page","library"]},"system-info":{"title":"System Info","icon":"info-circle-o","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin.php?page=elementor-system-info","keywords":["system","info","environment","elementor"]},"role-manager":{"title":"Role Manager","icon":"person","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin.php?page=elementor-role-manager","keywords":["role","manager","user","elementor"]},"knowledge-base":{"title":"Knowledge Base","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin.php?page=go_knowledge_base_site","keywords":["help","knowledge","docs","elementor"]},"theme-builder":{"title":"Theme Builder","icon":"library-save","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin.php?page=elementor-app&ver=3.18.3#site-editor\/promotion","keywords":["template","header","footer","single","archive","search","404","library"]},"kit-library":{"title":"Kit Library","icon":"kit-parts","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin.php?page=elementor-app&ver=3.18.3#\/kit-library","keywords":["kit library","kit","library","site parts","parts","assets","templates"]}},"name":"general"},"create":{"title":"Create","dynamic":false,"items":{"page":{"title":"Add New Page Template","icon":"plus-circle-o","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/edit.php?action=elementor_new_post&post_type=elementor_library&template_type=page&_wpnonce=cae4c59bcd","keywords":["Add New Page Template","post","page","template","new","create"]},"section":{"title":"Add New Section","icon":"plus-circle-o","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/edit.php?action=elementor_new_post&post_type=elementor_library&template_type=section&_wpnonce=cae4c59bcd","keywords":["Add New Section","post","page","template","new","create"]},"wp-post":{"title":"Add New Post","icon":"plus-circle-o","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/edit.php?action=elementor_new_post&post_type=post&template_type=wp-post&_wpnonce=cae4c59bcd","keywords":["Add New Post","post","page","template","new","create"]},"wp-page":{"title":"Add New Page","icon":"plus-circle-o","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/edit.php?action=elementor_new_post&post_type=page&template_type=wp-page&_wpnonce=cae4c59bcd","keywords":["Add New Page","post","page","template","new","create"]},"landing-page":{"title":"Add New Landing Page","icon":"plus-circle-o","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/edit.php?action=elementor_new_post&post_type=e-landing-page&template_type=landing-page&_wpnonce=cae4c59bcd#library","keywords":["Add New Landing Page","post","page","template","new","create"]}},"name":"create"},"site":{"title":"Site","dynamic":false,"items":{"homepage":{"title":"Homepage","url":"https:\/\/santhoshavidhyalaya.com","icon":"home-heart","keywords":["home","page"]},"wordpress-dashboard":{"title":"Dashboard","icon":"dashboard","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/","keywords":["dashboard","wordpress"]},"wordpress-menus":{"title":"Menus","icon":"wordpress","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/nav-menus.php","keywords":["menu","wordpress"]},"wordpress-themes":{"title":"Themes","icon":"wordpress","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/themes.php","keywords":["themes","wordpress"]},"wordpress-customizer":{"title":"Customizer","icon":"wordpress","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/customize.php","keywords":["customizer","wordpress"]},"wordpress-plugins":{"title":"Plugins","icon":"wordpress","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/plugins.php","keywords":["plugins","wordpress"]},"wordpress-users":{"title":"Users","icon":"wordpress","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/users.php","keywords":["users","profile","wordpress"]},"apps":{"title":"Apps","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin.php?page=elementor-apps","icon":"apps","keywords":["apps","addon","plugin","extension","integration"]}},"name":"site"},"settings":{"title":"Settings","dynamic":false,"items":{"general-settings":{"title":"General Settings","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin.php?page=elementor","keywords":["general","settings","elementor"]},"advanced":{"title":"Advanced","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin.php?page=elementor#tab-advanced","keywords":["advanced","settings","elementor"]},"experiments":{"title":"Experiments","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin.php?page=elementor#tab-experiments","keywords":["settings","elementor","experiments"]},"element-manager":{"title":"Element Manager","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin.php?page=elementor-element-manager","keywords":["settings","elements","widgets","manager"]}},"name":"settings"},"tools":{"title":"Tools","dynamic":false,"items":{"tools":{"title":"Tools","icon":"tools","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin.php?page=elementor-tools","keywords":["tools","regenerate css","safe mode","debug bar","sync library","elementor"]},"replace-url":{"title":"Replace URL","icon":"tools","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin.php?page=elementor-tools#tab-replace_url","keywords":["tools","replace url","domain","elementor"]},"maintenance-mode":{"title":"Maintenance Mode","icon":"tools","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin.php?page=elementor-tools#tab-maintenance_mode","keywords":["tools","maintenance","coming soon","elementor"]},"import-export":{"title":"Import Export","icon":"import-export","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin.php?page=elementor-tools#tab-import-export-kit","keywords":["tools","import export","import","export","kit"]},"version-control":{"title":"Version Control","icon":"time-line","url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin.php?page=elementor-tools#tab-versions","keywords":["tools","version","control","rollback","beta","elementor"]}},"name":"tools"}}},"connect":[],"event-tracker":{"isUserDataShared":true}};
    /* ]]> */
    </script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/plugins/elementor/assets/js/common.min.js?ver=3.18.3" id="elementor-common-js"></script>
    <script type="text/javascript" id="elementor-app-loader-js-before">
    /* <![CDATA[ */
    var elementorAppConfig = {"menu_url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin.php?page=elementor-app&ver=3.18.3#site-editor\/promotion","assets_url":"https:\/\/santhoshavidhyalaya.com\/wp-content\/plugins\/elementor\/assets\/","pages_url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/edit.php?post_type=page","return_url":"https:\/\/santhoshavidhyalaya.com\/gallery-3\/","hasPro":false,"admin_url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/","login_url":"https:\/\/santhoshavidhyalaya.com\/wp-login.php","base_url":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin.php?page=elementor-app&ver=3.18.3","site-editor":[],"import-export":[],"kit-library":[],"onboarding":[]};
    /* ]]> */
    </script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/plugins/elementor/assets/js/app-loader.min.js?ver=3.18.3" id="elementor-app-loader-js"></script>
    <script type="text/javascript" id="wpcf7cf-scripts-js-extra">
    /* <![CDATA[ */
    var wpcf7cf_global_settings = {"ajaxurl":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin-ajax.php"};
    /* ]]> */
    </script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/plugins/cf7-conditional-fields/js/scripts.js?ver=2.4.6" id="wpcf7cf-scripts-js"></script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/plugins/jquery-validation-for-contact-form-7/includes/assets/js/jquery.validate.min.js?ver=5.4.2" id="jvcf7_jquery_validate-js"></script>
    <script type="text/javascript" id="jvcf7_validation-js-extra">
    /* <![CDATA[ */
    var scriptData = {"jvcf7_default_settings":{"jvcf7_show_label_error":"errorMsgshow","jvcf7_invalid_field_design":"theme_0"}};
    /* ]]> */
    </script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/plugins/jquery-validation-for-contact-form-7/includes/assets/js/jvcf7_validation.js?ver=5.4.2" id="jvcf7_validation-js"></script>
    <script type="text/javascript" id="eael-general-js-extra">
    /* <![CDATA[ */
    var localize = {"ajaxurl":"https:\/\/santhoshavidhyalaya.com\/wp-admin\/admin-ajax.php","nonce":"802d2f5bb4","i18n":{"added":"Added ","compare":"Compare","loading":"Loading..."},"eael_translate_text":{"required_text":"is a required field","invalid_text":"Invalid","billing_text":"Billing","shipping_text":"Shipping","fg_mfp_counter_text":"of"},"page_permalink":"https:\/\/santhoshavidhyalaya.com\/contact-us\/","cart_redirectition":"","cart_page_url":"","el_breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}};
    /* ]]> */
    </script>
    <script type="text/javascript" src="https://santhoshavidhyalaya.com/wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/js/view/general.min.js?ver=5.9.7" id="eael-general-js"></script>
    
    <script>
        function show_alert() {
      alert("Form Submit Sucessfully");
    }
    </script><div id="mm-blocker" class="mm-slideout"></div><iframe frameborder="0" scrolling="no" style="background-color: transparent; border: 0px; display: none;"></iframe><div id="GOOGLE_INPUT_CHEXT_FLAG" style="display: none;" input="" input_stat="{&quot;tlang&quot;:true,&quot;tsbc&quot;:true,&quot;pun&quot;:true,&quot;mk&quot;:true,&quot;ss&quot;:true}"></div></body></html>



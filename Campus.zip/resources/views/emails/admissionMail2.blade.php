<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>mail</title>
</head>

    
   <body style="font-family: Arial, sans-serif; line-height: 1.6;">
       
      
    <p>Dear {{$name}},</p>

    <p>Dear Parent,</p>

    <p>We are pleased to inform you that your child’s application has been successfully submitted through our online portal.</p>

    <p>Kindly note that we may require some mandatory documents or information. We would contact you over email or your registered mobile number.</p>

    <p>If you have any questions or need assistance, feel free to contact our admissions team.</p>

    <p>Thank you for choosing Santhosha Vidhyalaya</p>

    <p>Warm regards,</p>
    <p>Admissions Coordinator<br>
    Santhosha Vidhyalaya<br>
    80125 12143</p>

    <!--<p>Here are the details you provided:</p>-->

    <!--<ul>-->
    <!--    <li><strong>Child's Full Name:</strong> {{$child_name}}</li>-->
    <!--    <li><strong>Grade/Class Applied for:</strong> {{$class_name}}</li>-->
    <!--</ul>-->

    <!--<p>Should any additional documents or information be required, our admissions office will reach out to you promptly. For any questions or concerns, please feel free to reach us via email at <a href="mailto:admissions@santhoshavidhyalaya.com">admissions@santhoshavidhyalaya.com</a> or <a href="mailto:principal@santhoshavidhyalaya.com">principal@santhoshavidhyalaya.com</a>. Alternatively, you may contact us by phone at 80125 12100 or 80125 12143.</p>-->

    <!--<p>We truly value your interest in Santhosha Vidhyalaya, and we eagerly anticipate the possibility of welcoming you and your child to our educational community.</p>-->

    <!--<p>Regards,</p>-->
    <!--<p>Lydia Premakumari J<br>Principal<br>Santhosha Vidhyalaya</p>-->

</body>

</html>

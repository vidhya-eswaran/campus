// import React from 'react';
// // import './dashboard.css'
// import Header from '../Header';
// import Sidebar from '../Sidebar';
// import Footer from '../Footer';
// import {MdSchool} from 'react-icons/md';
// import {AiOutlineCloudUpload} from 'react-icons/ai';
// import Paper from '@mui/material/Paper'; 
// // import DatatableSprofile from '../MangerUser/DatatableSprofile';
// import Row from 'react-bootstrap/Row';
// import Button from 'react-bootstrap/Button'

// const Profile = () => {
//   return (
//     <div>
//        <Sidebar/>
//     <div style={{width:'82.5%',float:'right'}} >
//       <Header/>
//     <section className='p-4'>
//         <h4><MdSchool className='pb-1 pe-2' size={35}/>Student Profile</h4>
//         <hr className='settingHr'/>

//         <div className='py-1'>
//           <Paper elevation={2} className="pb-5">
//              <Row>
//                <div className='col-6 p-4'><h4>Manger user</h4></div>
//                  <div className='col-6 text-end p-4'>
//                   {/* <button  style={{width:'25%'}} className='button-42 ' role='button'>Add user</button> */}
//                   <a href='/StudentProfile/Bulkupload'><Button style={{backgroundColor:'#FE8C00'}}><AiOutlineCloudUpload className='pe-2' size={30}/>Bulk Upload</Button></a>{' '}
//                </div>
//              </Row>

//              <div className='container'>
//                {/* <DatatableSprofile/> */}
//              </div>
//           </Paper>
//           </div>
//     </section>
//     </div>
//     </div>
//   )
// }

// export default Profile

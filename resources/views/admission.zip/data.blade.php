
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
											<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap.min.css">
											<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.bootstrap.min.css">
											<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.bootstrap.min.css">
											<body>
                                            <section style="width: 100%;display: flex;background: #fff8f0;">
   

</section>
 <div class="container">
<div class="row">
<div class="col-md-2" style="text-align:-webkit-center">
<div style="   width:20%; text-align: center;
    align-self: center;"><img src="{{ asset('public/images/1.png') }}"></div>
    </div>
    <div class="col-md-10" style="text-align:-webkit-center">
<div style="width:80%;text-align: center;"><h4 style="font-size: 2.8rem;
    text-align: center;
    margin-bottom: 0px;
    color: #962423;">Santhosha Vidhyalaya </h4>
    <p style="margin-bottom: 0px;
    text-align: center;
    font-weight: 600;
    font-size: 1.3rem;
    color: #962423;
">Admission Application Form 2024 - 2025</p>
    <p class="cinfo" style="color: #962423;">
       <span style="margin-right: 5px;"><i class="fas fa-phone"></i>  +91 80125 12100</span>
       <span style="margin-right: 5px;"><i class="fas fa-envelope"></i>  admissions@santhoshavidhyalaya.com </span>
       <span style="margin-right: 5px;"><i class="fas fa-map-marker-alt"></i>Dohnavur – 627102 Tirunelveli Dist. Tamilnadu</span>
    </p></div>
<div style="width: 20%; text-align: center;
    align-self: center;">

</div>
</div>
</div></div>
											    <div class="container">
											        <div class="row">
											    <div class="col-md-12">
											  <table id="example" class="table table-striped table-bordered nowrap dataTable no-footer dtr-inline collapsed" style="width: 100%;" aria-describedby="example_info"><thead>
							<tr>
							    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">id</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">name</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">date_form</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">language</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">state_student</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">date_of_birth</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">gender</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">blood_group</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">nationality</th>
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">religion</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">church_denomination</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">caste</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">caste_type</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">aadhar_card_no</th>
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">ration_card_no</th>
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">emis_no</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">veg_or_non</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">chronic_des</th>
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">medicine_taken</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">father_name</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">father_occupation</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">mother_name</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">mother_occupation</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">guardian_name</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">guardian_occupation</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">father_contact_no</th>
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">father_email_id</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">mother_contact_no</th>
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">mother_email_id</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">guardian_contact_no</th>
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">guardian_email_id</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">father_income</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">mother_income</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">guardian_income</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">house_no</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">street</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">city</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">district</th>
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">state</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">pincode</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">house_no_1</th>
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">street_1</th>
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">city_1</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">district_1</th>
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">state_1</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">pincode_1</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">last_class_std</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">last_school</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">admission_for_class</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">syllabus</th>
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">group_no</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">second_group_no</th>
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">second_language</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">profile_photo</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">birth_certificate_photo</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">aadhar_card_photo</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">ration_card_photo</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">community_certificate</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">slip_photo</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">medical_certificate_photo</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">reference_letter_photo</th>
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">church_certificate_photo</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">transfer_certificate_photo</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">admission_photo</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">payment_order_id</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">brother_1</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">brother_2</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">gender_1</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">gender_2</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">class_1</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">class_2</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">brother_3</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">gender_3</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">class_3</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">last_school_state</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">second_language_school</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">reference_name_1</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">reference_name_2</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">reference_phone_1</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">reference_phone_2</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">father_organization</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">mother_organization</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">guardian_organization</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">created_at</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">updated_at</th> 
    <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 71.25px;" aria-sort="ascending" aria-label="First name: activate to sort column descending">documents</th> 
							<!--<th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 70.3125px;" aria-label="Last name: activate to sort column ascending">Last name</th><th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 174.625px;" aria-label="Position: activate to sort column ascending">Position</th><th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 77.25px;" aria-label="Office: activate to sort column ascending">Office</th><th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 27.5625px;" aria-label="Age: activate to sort column ascending">Age</th><th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 65.3438px;" aria-label="Start date: activate to sort column ascending">Start date</th><th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 57.25px;" aria-label="Salary: activate to sort column ascending">Salary</th><th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 35.5938px;" aria-label="Extn.: activate to sort column ascending">Extn.</th><th class="sorting dtr-hidden" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 0px; display: none;" aria-label="E-mail: activate to sort column ascending">E-mail</th>-->
							</tr>
						</thead>
						
						<tbody>
							
            @foreach ($data as $item)
						<tr class="odd">
								<!--<td class="dtr-control sorting_1" tabindex="0">Airi</td>-->
							
								<td>{{$item['id']}}</td> 
    <td>{{$item['name']}}</td> 
    <td>{{$item['date_form']}}</td> 
    <td>{{$item['language']}}</td> 
    <td>{{$item['state_student']}}</td> 
    <td>{{$item['date_of_birth']}}</td> 
    <td>{{$item['gender']}}</td> 
    <td>{{$item['blood_group']}}</td> 
    <td>{{$item['nationality']}}</td>
    <td>{{$item['religion']}}</td> 
    <td>{{$item['church_denomination']}}</td> 
    <td>{{$item['caste']}}</td> 
    <td>{{$item['caste_type']}}</td> 
    <td>{{$item['aadhar_card_no']}}</td>
    <td>{{$item['ration_card_no']}}</td>
    <td>{{$item['emis_no']}}</td> 
    <td>{{$item['veg_or_non']}}</td> 
    <td>{{$item['chronic_des']}}</td>
    <td>{{$item['medicine_taken']}}</td> 
    <td>{{$item['father_name']}}</td> 
    <td>{{$item['father_occupation']}}</td> 
    <td>{{$item['mother_name']}}</td> 
    <td>{{$item['mother_occupation']}}</td> 
    <td>{{$item['guardian_name']}}</td> 
    <td>{{$item['guardian_occupation']}}</td> 
    <td>{{$item['father_contact_no']}}</td>
    <td>{{$item['father_email_id']}}</td> 
    <td>{{$item['mother_contact_no']}}</td>
    <td>{{$item['mother_email_id']}}</td> 
    <td>{{$item['guardian_contact_no']}}</td>
    <td>{{$item['guardian_email_id']}}</td> 
    <td>{{$item['father_income']}}</td> 
    <td>{{$item['mother_income']}}</td> 
    <td>{{$item['guardian_income']}}</td> 
    <td>{{$item['house_no']}}</td> 
    <td>{{$item['street']}}</td> 
    <td>{{$item['city']}}</td> 
    <td>{{$item['district']}}</td>
    <td>{{$item['state']}}</td> 
    <td>{{$item['pincode']}}</td> 
    <td>{{$item['house_no_1']}}</td>
    <td>{{$item['street_1']}}</td>
    <td>{{$item['city_1']}}</td> 
    <td>{{$item['district_1']}}</td>
    <td>{{$item['state_1']}}</td> 
    <td>{{$item['pincode_1']}}</td> 
    <td>{{$item['last_class_std']}}</td> 
    <td>{{$item['last_school']}}</td> 
    <td>{{$item['admission_for_class']}}</td> 
    <td>{{$item['syllabus']}}</td>
    <td>{{$item['group_no']}}</td> 
    <td>{{$item['second_group_no']}}</td>
    <td>{{$item['second_language']}}</td> 
    <td>{{$item['profile_photo']}}</td> 
    <td>{{$item['birth_certificate_photo']}}</td> 
    <td>{{$item['aadhar_card_photo']}}</td> 
    <td>{{$item['ration_card_photo']}}</td> 
    <td>{{$item['community_certificate']}}</td> 
    <td>{{$item['slip_photo']}}</td> 
    <td>{{$item['medical_certificate_photo']}}</td> 
    <td>{{$item['reference_letter_photo']}}</td>
    <td>{{$item['church_certificate_photo']}}</td> 
    <td>{{$item['transfer_certificate_photo']}}</td> 
    <td>{{$item['admission_photo']}}</td> 
    <td>{{$item['payment_order_id']}}</td> 
    <td>{{$item['brother_1']}}</td> 
    <td>{{$item['brother_2']}}</td> 
    <td>{{$item['gender_1']}}</td> 
    <td>{{$item['gender_2']}}</td> 
    <td>{{$item['class_1']}}</td> 
    <td>{{$item['class_2']}}</td> 
    <td>{{$item['brother_3']}}</td> 
    <td>{{$item['gender_3']}}</td> 
    <td>{{$item['class_3']}}</td> 
    <td>{{$item['last_school_state']}}</td> 
    <td>{{$item['second_language_school']}}</td> 
    <td>{{$item['reference_name_1']}}</td> 
    <td>{{$item['reference_name_2']}}</td> 
    <td>{{$item['reference_phone_1']}}</td> 
    <td>{{$item['reference_phone_2']}}</td> 
    <td>{{$item['father_organization']}}</td> 
    <td>{{$item['mother_organization']}}</td> 
    <td>{{$item['guardian_organization']}}</td> 
    <td>{{$item['created_at']}}</td> 
    <td>{{$item['updated_at']}}</td> 
    <td><a href="https://santhoshavidhyalaya.com/SVS/documents/{{$item['id']}}">View Documents</a></td>
								<!--<td>Accountant</td>-->
								<!--<td>Tokyo</td>-->
								<!--<td>33</td>-->
								<!--<td>2008-11-28</td>-->
								<!--<td>$162,700</td>-->
								<!--<td>5407</td>-->
								<!--<td class="dtr-hidden" style="display: none;">a.satou@datatables.net</td>-->
								</tr>
								 @endforeach
						</tbody>
					</table>
					</div>
						</div>
							</div>
										
						<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
							<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
								<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap.min.js"></script>
									<script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
										<script src="https://cdn.datatables.net/responsive/2.5.0/js/responsive.bootstrap.min.js"></script>
											<!-- <script src="https://cdn.datatables.net/responsive/2.4.1/js/responsive.bootstrap.min.js"></script> -->
											<script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
											<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.bootstrap.min.js"></script>
											<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
											<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
											<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
											<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
											<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>
											<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.colVis.min.js"></script>
											<script>
											    $(document).ready(function() {
    var table = $('#example').DataTable( {
        
        responsive: true,
         buttons: [ 'copy', 'excel', 'pdf', 'colvis' ]
         
    } );
 table.buttons().container()
        .appendTo( '#example_wrapper .col-sm-6:eq(0)' );
    new $.fn.dataTable.FixedHeader( table );
} );
											</script>
									
										</body>